using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainGameManager : MonoBehaviour
{
    public AudioSource clickSound;

    public void ShiftToStartScene() 
    {
        clickSound.Play();
        SceneManager.LoadScene("StartScene");
        GameStarter.gameStarted = false;
        PlayerShooting.ammo = 0;
        PacStudentController.score = 0;
        PacStudentController.powerPelletEaten = false;
        PacStudentController.canEatPowerPellet = true;
    }
}
