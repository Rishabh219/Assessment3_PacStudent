using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer : MonoBehaviour
{
    public TextMeshProUGUI timerText; // Assign a UI Text element in the Inspector to display the timer

    public static float elapsedTime = 0f; // To keep track of the time

    void Update()
    {
        if (GameStarter.gameStarted)
        {
            elapsedTime += Time.deltaTime; // Add the time passed since the last frame

            // Convert elapsedTime into minutes, seconds, and milliseconds
            int minutes = (int)(elapsedTime / 60) % 60;
            int seconds = (int)(elapsedTime % 60);
            int milliseconds = (int)((elapsedTime * 100) % 100);

            // Format and display the timer in MM:SS:MS format
            timerText.text = string.Format("{0:00}:{1:00}:{2:00}", minutes, seconds, milliseconds);
        }

        if (HandleGameOver.gameOver) 
        {
            ResetTimer();
            HandleGameOver.gameOver = false;
        }
    }

    // Optional: Call this method to reset the timer when needed
    public void ResetTimer()
    {
        elapsedTime = 0f;
        timerText.text = "00:00:00";
    }
}
