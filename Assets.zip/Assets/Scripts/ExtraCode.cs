using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExtraCode : MonoBehaviour
{
    public Animator animatorController;

    [SerializeField]
    private GameObject player;
    private Vector3 moveDirection;
    public float moveSpeed = 5.0f;
    string lastInput = "";
    string currentInput = "";

    public bool canMoveUp = true;
    public bool canMoveDown = true;
    public bool canMoveLeft = true;
    public bool canMoveRight = true;

    public AudioSource wallCollisionAudio;

    public static int score = 0;

    public AudioSource movementAudio;
    public AudioSource pelletCollectAudio;

    bool hasCollided = false;
    bool buttonPressed = false;

    public GameObject moveParticle;
    public GameObject collideParticle;

    public static int pelletsEaten = 0;

    // Start is called before the first frame update
    void Start()
    {
        moveDirection = Vector3.zero; // Initialize with no movement
        moveParticle.SetActive(false);
        collideParticle.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

        if (gameObject.transform.position.x < 0)
        {
            gameObject.transform.position = new Vector2(27, gameObject.transform.position.y);
        }

        if (gameObject.transform.position.x > 27)
        {
            gameObject.transform.position = new Vector2(0, gameObject.transform.position.y);
        }

        //HandleInput();
        //MovePlayer();
        //checkDirection();

        if (GameStarter.gameStarted)
        {
            HandleInput();
            MovePlayer();
            checkDirection();

            //HandleMovement();
            //ManageMotion();
        }
    }

    void ManageMotion()
    {
        if (lastInput == "W" && canMoveUp)
        {
            moveParticle.SetActive(true);
            moveDirection = Vector3.up; // Move up
            animatorController.SetInteger("Move", 1); // Up animation
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0); // Ensure player faces upward correctly
            player.transform.position += moveDirection * moveSpeed * Time.deltaTime;
        }

        else if (lastInput == "S" && canMoveDown)
        {
            moveParticle.SetActive(true);
            moveDirection = Vector3.down; // Move down
            animatorController.SetInteger("Move", 3); // Down animation
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0); // Ensure player faces downward correctly
            player.transform.position += moveDirection * moveSpeed * Time.deltaTime;
        }

        else if (lastInput == "A" && canMoveLeft)
        {
            moveParticle.SetActive(true);
            moveDirection = Vector3.left; // Move left
            animatorController.SetInteger("Move", 0); // Left animation
            player.transform.localScale = new Vector3(-2.2f, 2.2f, 0); // Flip the player to face left
            player.transform.position += moveDirection * moveSpeed * Time.deltaTime;

        }

        else if (lastInput == "D" && canMoveRight)
        {
            moveParticle.SetActive(true);
            moveDirection = Vector3.right; // Move left
            animatorController.SetInteger("Move", 2); // Left animation
            player.transform.localScale = new Vector3(-2.2f, 2.2f, 0); // Flip the player to face left
            player.transform.position += moveDirection * moveSpeed * Time.deltaTime;

        }
    }

    void HandleMovement()
    {
        if (Input.GetKey(KeyCode.W))
        {
            lastInput = "W";
        }
        else if (Input.GetKey(KeyCode.S))
        {
            lastInput = "S";
        }
        else if (Input.GetKey(KeyCode.A))
        {
            lastInput = "A";
        }
        else if (Input.GetKey(KeyCode.D))
        {
            lastInput = "D";
        }
    }

    void HandleInput()
    {
        // Handle WASD key input and set the move direction accordingly
        if (Input.GetKey(KeyCode.W))
        {
            moveDirection = Vector3.up; // Move down
            lastInput = "W";
        }
        else if (Input.GetKey(KeyCode.S))
        {
            moveDirection = Vector3.down; // Move down
            lastInput = "S";
        }
        else if (Input.GetKey(KeyCode.A))
        {
            moveDirection = Vector3.left; // Move left
            lastInput = "A";
        }
        else if (Input.GetKey(KeyCode.D))
        {
            moveDirection = Vector3.right; // Move right
            lastInput = "D";
        }
    }



    void MovePlayer()
    {
        // Move the player in the set direction at a fixed speed
        if (moveDirection != Vector3.zero)
        {
            player.transform.position += moveDirection * moveSpeed * Time.deltaTime;
        }
    }

    public void checkDirection()
    {
        // Update animation based on movement direction
        if (moveDirection == Vector3.up)
        {
            animatorController.SetInteger("Move", 1); // Up animation
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0); // Ensure player faces upward correctly
        }
        else if (moveDirection == Vector3.down)
        {
            animatorController.SetInteger("Move", 3); // Down animation
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0); // Ensure player faces downward correctly
        }
        else if (moveDirection == Vector3.left)
        {
            animatorController.SetInteger("Move", 0); // Left animation
            player.transform.localScale = new Vector3(-2.2f, 2.2f, 0); // Flip the player to face left
        }
        else if (moveDirection == Vector3.right)
        {
            animatorController.SetInteger("Move", 2); // Right animation
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0); // Ensure player faces right
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("1") || collision.CompareTag("2") || collision.CompareTag("3") || collision.CompareTag("4") || collision.CompareTag("7"))
        {
            collideParticle.SetActive(false);

        }
    }

    void HandleCollision()
    {
        if (lastInput == "W")
        {
            canMoveUp = false;
            canMoveDown = true;
            canMoveRight = true;
            canMoveLeft = true;
            player.transform.position -= moveDirection * moveSpeed * Time.deltaTime;
        }

        if (lastInput == "A")
        {
            canMoveUp = true;
            canMoveDown = true;
            canMoveRight = true;
            canMoveLeft = false;
            player.transform.position -= moveDirection * moveSpeed * Time.deltaTime;
        }

        if (lastInput == "S")
        {
            canMoveUp = true;
            canMoveDown = false;
            canMoveRight = true;
            canMoveLeft = true;
            player.transform.position -= moveDirection * moveSpeed * Time.deltaTime;
        }

        if (lastInput == "D")
        {
            canMoveUp = true;
            canMoveDown = true;
            canMoveRight = false;
            canMoveLeft = true;
            player.transform.position -= moveDirection * moveSpeed * Time.deltaTime;
        }
    }

    void ManageCollisions()
    {
        while (!buttonPressed)
        {
            if (lastInput == "W")
            {
                if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.A))
                {
                    moveSpeed = 5.0f;
                    buttonPressed = true;
                }
            }

            if (lastInput == "A")
            {
                if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.W))
                {
                    moveSpeed = 5.0f;
                    buttonPressed = true;
                }
            }

            if (lastInput == "S")
            {
                if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A))
                {
                    moveSpeed = 5.0f;
                    buttonPressed = true;
                }
            }

            if (lastInput == "D")
            {
                if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.A))
                {
                    moveSpeed = 5.0f;
                    buttonPressed = true;
                }
            }
        }
        hasCollided = false;
        buttonPressed = false;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        //Debug.Log(collision.tag);

        if (GameStarter.gameStarted)
        {
            if (collision.CompareTag("1") || collision.CompareTag("2") || collision.CompareTag("3") || collision.CompareTag("4") || collision.CompareTag("7"))
            {
                collideParticle.SetActive(true);
                moveParticle.SetActive(false);
                wallCollisionAudio.Play();

                player.transform.position -= moveDirection * moveSpeed * Time.deltaTime;

                //HandleCollision();
            }

            if (collision.CompareTag("5"))
            {
                score += 10;
                Destroy(collision.gameObject);
                pelletCollectAudio.Play();
                pelletsEaten++;
                //Debug.Log(pelletsEaten);
            }

            if (collision.CompareTag("Cherry"))
            {
                score += 100;
                collision.gameObject.SetActive(false);
                pelletCollectAudio.Play();
            }

            if (collision.CompareTag("Ghost"))
            {
                HandleGameOver.totalLives--;
            }
        }
    }
}