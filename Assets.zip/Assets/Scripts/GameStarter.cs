using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStarter : MonoBehaviour
{
    public static bool gameStarted = false;
    public GameObject oneText;
    public GameObject twoText;
    public GameObject threeText;
    public GameObject goText;
    float waitTime = 1f;

    void Start()
    {
        StartCoroutine(StartGame());
        
    }

    IEnumerator StartGame() 
    {
        threeText.SetActive(true);
        yield return new WaitForSeconds(waitTime);
        threeText.SetActive(false);
        twoText.SetActive(true);
        yield return new WaitForSeconds(waitTime);
        twoText.SetActive(false);
        oneText.SetActive(true);
        yield return new WaitForSeconds(waitTime);
        oneText.SetActive(false);
        goText.SetActive(true);
        yield return new WaitForSeconds(waitTime);
        goText.SetActive(false);
        gameStarted = true;
    }
}
