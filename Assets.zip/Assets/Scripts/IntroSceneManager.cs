using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class IntroSceneManager : MonoBehaviour
{
    public AudioSource backgroundMusic;
    public AudioSource clickSound;
    public TextMeshProUGUI highScoreText;
    public TextMeshProUGUI bestTimerText;
    public static int highScore = 0;
    public static float bestTime = 0;

    void Start()
    {
        LoadGame();
        //highScore = 0;
        //bestTime = 0;
    }

    void Update()
    {
        highScoreText.text = highScore.ToString();

        int minutes = (int)(bestTime / 60) % 60;
        int seconds = (int)(bestTime % 60);
        int milliseconds = (int)((bestTime * 100) % 100);

        // Format and display the timer in MM:SS:MS format
        bestTimerText.text = string.Format("{0:00}:{1:00}:{2:00}", minutes, seconds, milliseconds);
    }

    public void LoadGame()
    {
        highScore = PlayerPrefs.GetInt("Highscore", 0);
        bestTime = PlayerPrefs.GetFloat("BestTime", 0);
    }

    public void ShiftToLevel1() 
    {
        clickSound.Play();
        SceneManager.LoadScene("Pacman");
    }

    public void ShiftToLevel2()
    {
        clickSound.Play();
        SceneManager.LoadScene("InnovationScene");
    }
}
