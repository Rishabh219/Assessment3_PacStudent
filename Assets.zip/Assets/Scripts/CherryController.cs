using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CherryController : MonoBehaviour
{
    public GameObject cherry;
    float spawnTimer = 10f;
    float speed = 1f;
    public Vector2[] spawnPositons;
    bool isSpawning = false;
    Vector2 spawnPoint;
    public int spawnDecider;

    void Update()
    {
        if (!isSpawning)
        {
            isSpawning = true;
            StartCoroutine(SpawnCherry());
        }
    }

    IEnumerator SpawnCherry()
    {
        yield return new WaitForSeconds(spawnTimer);

        spawnDecider = Random.Range(0, spawnPositons.Length);
        spawnPoint = spawnPositons[spawnDecider];

        GameObject newCherry = Instantiate(cherry, spawnPoint, Quaternion.identity);

        newCherry.tag = "Cherry";

        // Move the cherry in the direction based on spawnDecider
        if (spawnDecider == 0)
        {
            while (newCherry.transform.position.x < 46.75f)
            {
                newCherry.transform.Translate(Vector2.right * speed * Time.deltaTime);
                yield return null;
            }
        }
        else if (spawnDecider == 1)
        {
            while (newCherry.transform.position.x > -20.5f)
            {
                newCherry.transform.Translate(Vector2.left * speed * Time.deltaTime);
                yield return null;
            }
        }
        else if (spawnDecider == 2)
        {
            while (newCherry.transform.position.y > -31.5f)
            {
                newCherry.transform.Translate(Vector2.down * speed * Time.deltaTime);
                yield return null;
            }
        }
        else if (spawnDecider == 3)
        {
            while (newCherry.transform.position.y < -1f)
            {
                newCherry.transform.Translate(Vector2.up * speed * Time.deltaTime);
                yield return null;
            }
        }

        // Destroy the cherry after it reaches the boundary
        Destroy(newCherry);
        isSpawning = false;
    }
}
