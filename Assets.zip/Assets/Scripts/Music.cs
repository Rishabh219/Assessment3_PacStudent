﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicManager : MonoBehaviour
{

    public AudioSource audioSource;
    public AudioClip introMusic;
    public AudioClip ghostNormalMusic;
    public AudioSource scaredGhostMusic;

    // Start is called before the first frame update
    void Start()
    {
        // Plays intro music
        audioSource.Play();
    }

    // Update is called once per frame
    void Update()
    {
        // Plays ghost normal state music
        if (!audioSource.isPlaying && !PacStudentController.powerPelletEaten)
        {
            audioSource.clip = ghostNormalMusic;
            audioSource.Play();

            if (scaredGhostMusic.isPlaying) 
            {
                scaredGhostMusic.Stop();
            }
        }

        else if (PacStudentController.powerPelletEaten) 
        {
            if (audioSource.isPlaying)
            {
                audioSource.Stop();
            }

            scaredGhostMusic.Play();
        }
    }
}
