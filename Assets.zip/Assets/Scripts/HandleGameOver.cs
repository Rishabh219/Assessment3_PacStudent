using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;

public class HandleGameOver : MonoBehaviour
{
    public GameObject gameOverText;
    public static int totalLives = 3;
    public static bool gameOver = false;
    int bestScore = 0;
    float bestTime = 0;

    public GameObject[] lives;

    void Start()
    {
        for (int i = 0; i < lives.Length; i++) 
        {
            lives[i].SetActive(true);
        }
    }

    void Update()
    {
        if (PacStudentController.pelletsEaten >= 220 || totalLives <= 0) // 220
        {
            StartCoroutine(GameOver());
        }

        if (totalLives == 1)
        {
            lives[0].SetActive(true);
            lives[1].SetActive(false);
            lives[2].SetActive(false);
        }
        else if (totalLives == 2)
        {
            lives[0].SetActive(true);
            lives[1].SetActive(true);
            lives[2].SetActive(false);
        }
        else if (totalLives >= 3)
        {
            lives[0].SetActive(true);
            lives[1].SetActive(true);
            lives[2].SetActive(true);
        }
        else if (totalLives <= 0) 
        {
            lives[0].SetActive(false);
            lives[1].SetActive(false);
            lives[2].SetActive(false);
        }
    }

    public void SaveHighScore()
    {
        PlayerPrefs.SetInt("Highscore", bestScore);
        PlayerPrefs.Save();
    }

    public void SaveBestTime()
    {
        PlayerPrefs.SetFloat("BestTime", bestTime);
        PlayerPrefs.Save();
    }

    IEnumerator GameOver() 
    {
        if (PacStudentController.score > IntroSceneManager.highScore) 
        {
            IntroSceneManager.highScore = PacStudentController.score;
            bestScore = IntroSceneManager.highScore;
            SaveHighScore();
        }

        if (IntroSceneManager.bestTime == 0) 
        {
            IntroSceneManager.bestTime = Timer.elapsedTime;
            bestTime = IntroSceneManager.bestTime;
            SaveBestTime();
        }
        else if (Timer.elapsedTime < IntroSceneManager.bestTime) 
        {
            IntroSceneManager.bestTime = Timer.elapsedTime;
            bestTime = IntroSceneManager.bestTime;
            SaveBestTime();
        }

        gameOverText.SetActive(true);
        GameStarter.gameStarted = false;
        yield return new WaitForSeconds(3);
        SceneManager.LoadScene("StartScene");
        gameOverText.SetActive(false);
        PacStudentController.pelletsEaten = 0;
        totalLives = 3;
        PacStudentController.score = 0;
        gameOver = true;




    }
}
