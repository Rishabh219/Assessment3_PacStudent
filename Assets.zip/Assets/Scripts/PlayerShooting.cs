using UnityEngine;
using TMPro;

public class PlayerShooting : MonoBehaviour
{
    public GameObject bulletPrefab;    // Reference to the bullet prefab
    public float bulletSpeed = 10f;    // Speed of the bullet
    public Transform firePoint;
    public Transform player;
    Vector2 shootingDirection;
    public static int ammo = 0;
    public TextMeshProUGUI ammoText;
    public TextMeshProUGUI ammoAmount;
    public AudioSource shootSound;

    void Start()
    {
        shootingDirection = player.right;
    }

    void Update()
    {
        ammoAmount.text = ammo.ToString();

        if (GameStarter.gameStarted) 
        {
            AimAndShoot();

            if (Input.GetKeyDown(KeyCode.W))
            {
                shootingDirection = player.up;
            }

            if (Input.GetKeyDown(KeyCode.A))
            {
                shootingDirection = player.right * -1;
            }

            if (Input.GetKeyDown(KeyCode.S))
            {
                shootingDirection = player.up * -1;
            }

            if (Input.GetKeyDown(KeyCode.D))
            {
                shootingDirection = player.right;
            }
        }

    }

    void AimAndShoot()
    {
        // Rotate player towards mouse position
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 direction = shootingDirection;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0, 0, angle);

        if (Input.GetKeyDown(KeyCode.Space))  // 0 for left-click
        {
            if (ammo > 0) 
            {
                Shoot(direction);
            }
            
        }
    }

    void Shoot(Vector2 direction)
    {
        shootSound.Play();
        // Create a bullet instance at the fire point
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.velocity = direction * bulletSpeed;

        // Optionally, destroy bullet after a time to avoid clutter
        Destroy(bullet, 2f);

        ammo--;
    }
}
