using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicPlayer : MonoBehaviour
{
    public AudioSource normalMusic;
    public AudioSource ghostScaredMusic;

    private bool isGhostScaredPlaying = false;

    void Start()
    {
        normalMusic.Play();
    }

    void Update()
    {
        if (PacStudentController.powerPelletEaten)
        {
            if (!isGhostScaredPlaying)
            {
                normalMusic.Stop();
                ghostScaredMusic.Play();
                isGhostScaredPlaying = true;
            }
        }
        else
        {
            if (isGhostScaredPlaying)
            {
                ghostScaredMusic.Stop();
                normalMusic.Play();
                isGhostScaredPlaying = false;
            }
        }
    }
}
