﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PacStudentController : MonoBehaviour
{
    public Animator animatorController;
    public AudioSource wallCollisionAudio;
    public AudioSource movementAudio;
    public AudioSource pelletCollectAudio;
    public GameObject moveParticle;
    public GameObject collideParticle;
    public static int score = 0;
    public static int pelletsEaten = 0;

    [SerializeField] private GameObject player;
    private Vector3 moveDirection;
    private Vector3 targetPosition;
    public float moveSpeed = 5.0f;
    private bool isLerping = false;
    private string lastInput = "";
    private string currentInput = "";

    public bool canMoveUp = true;
    public bool canMoveDown = true;
    public bool canMoveLeft = true;
    public bool canMoveRight = true;
    private bool buttonPressed = false;
    private bool hasCollided = false;

    Vector2 startPosition;

    public static bool powerPelletEaten = false;
    public static bool canEatGhost = false;
    public static bool canEatPowerPellet = true;

    float ghostSpeed = 1f;
    public Transform homePosition;
    public float ghostWaitTime = 5f;

    public AudioSource deathSound;
    public AudioSource powerPelletSound;
    public AudioSource eatGhostSound;

    // Start is called before the first frame update
    void Start()
    {
        moveDirection = Vector3.zero;
        moveParticle.SetActive(false);
        collideParticle.SetActive(false);
        targetPosition = player.transform.position;
        startPosition = gameObject.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        // Implement teleportation logic
        if (gameObject.transform.position.x < 0)
        {
            gameObject.transform.position = new Vector2(27, gameObject.transform.position.y);
            targetPosition = gameObject.transform.position; // Reset target position for accurate collision
            isLerping = false; // Stop any ongoing movement
        }
        else if (gameObject.transform.position.x > 27)
        {
            gameObject.transform.position = new Vector2(0, gameObject.transform.position.y);
            targetPosition = gameObject.transform.position; // Reset target position for accurate collision
            isLerping = false;
        }

        if (GameStarter.gameStarted)
        {
            HandleInput();

            if (!isLerping)
            {
                TryMove(lastInput);
                if (!isLerping) TryMove(currentInput);
            }

            if (isLerping)
            {
                player.transform.position = Vector3.MoveTowards(player.transform.position, targetPosition, moveSpeed * Time.deltaTime);

                if (Vector3.Distance(player.transform.position, targetPosition) < 0.01f)
                {
                    player.transform.position = targetPosition;
                    isLerping = false;
                }
            }

            checkDirection();

            // Handle movement audio and particle effect
            if (isLerping)
            {
                if (!movementAudio.isPlaying) movementAudio.Play();
                if (!moveParticle.activeSelf) moveParticle.SetActive(true);
            }
            else
            {
                if (movementAudio.isPlaying) movementAudio.Stop();
                if (moveParticle.activeSelf) moveParticle.SetActive(false);
            }
        }
    }

    void HandleInput()
    {
        if (Input.GetKey(KeyCode.W)) lastInput = "W";
        else if (Input.GetKey(KeyCode.S)) lastInput = "S";
        else if (Input.GetKey(KeyCode.A)) lastInput = "A";
        else if (Input.GetKey(KeyCode.D)) lastInput = "D";
    }

    void TryMove(string inputDirection)
    {
        if (string.IsNullOrEmpty(inputDirection)) return;

        Vector3 checkDirection = Vector3.zero;

        switch (inputDirection)
        {
            case "W": checkDirection = Vector3.up; break;
            case "S": checkDirection = Vector3.down; break;
            case "A": checkDirection = Vector3.left; break;
            case "D": checkDirection = Vector3.right; break;
        }

        Vector3 potentialPosition = player.transform.position + checkDirection;

        if (IsWalkable(potentialPosition))
        {
            currentInput = inputDirection;
            targetPosition = potentialPosition;
            isLerping = true;
        }
    }

    bool IsWalkable(Vector3 position)
    {
        Collider2D hit = Physics2D.OverlapCircle(position, 0.1f);
        return hit == null || hit.CompareTag("5") || hit.CompareTag("6");
    }

    void checkDirection()
    {
        if (moveDirection == Vector3.up)
        {
            animatorController.SetInteger("Move", 1);
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0);
        }
        else if (moveDirection == Vector3.down)
        {
            animatorController.SetInteger("Move", 3);
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0);
        }
        else if (moveDirection == Vector3.left)
        {
            animatorController.SetInteger("Move", 0);
            player.transform.localScale = new Vector3(-2.2f, 2.2f, 0);
        }
        else if (moveDirection == Vector3.right)
        {
            animatorController.SetInteger("Move", 2);
            player.transform.localScale = new Vector3(2.2f, 2.2f, 0);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (GameStarter.gameStarted)
        {
            if (collision.CompareTag("1") || collision.CompareTag("2") || collision.CompareTag("3") || collision.CompareTag("4") || collision.CompareTag("7"))
            {
                collideParticle.SetActive(true);
                moveParticle.SetActive(false);
                wallCollisionAudio.Play();
                isLerping = false;
            }
            if (collision.CompareTag("5"))
            {
                score += 10;
                Destroy(collision.gameObject);
                pelletCollectAudio.Play();
                pelletsEaten++;
                //Debug.Log(pelletsEaten);
                PlayerShooting.ammo += 1;
            }
            if (collision.CompareTag("Cherry"))
            {
                score += 100;
                collision.gameObject.SetActive(false);
                pelletCollectAudio.Play();
            }

            if (collision.CompareTag("Ghost 1") || collision.CompareTag("Ghost 2") || collision.CompareTag("Ghost 3") || collision.CompareTag("Ghost 4"))
            {
                if (!canEatGhost) 
                {
                    deathSound.Play();
                    HandleGameOver.totalLives--;
                    gameObject.transform.position = startPosition;
                    moveParticle.SetActive(true);
                }
                else 
                {
                    eatGhostSound.Play();
                    score += 300;
                    ResetGhost(collision.gameObject);
                    //collision.gameObject.GetComponent<Animator>().Play("Ghost_DeathState");
                    //collision.gameObject.transform.position = homePosition.position;
                    //collision.GetComponent<GhostController>().enabled = false;
                    //collision.gameObject.GetComponent<NavMeshAgent>().enabled = false;
                    StartCoroutine(GhostRecover(collision.gameObject));
                }
            }

            if (collision.CompareTag("6")) 
            {
                if (canEatPowerPellet) 
                {
                    powerPelletEaten = true;
                    canEatGhost = true;
                    Destroy(collision.gameObject);
                    powerPelletSound.Play();
                    canEatPowerPellet = false;
                }
            }
        }
    }

    IEnumerator GhostRecover(GameObject ghost) 
    {
        yield return new WaitForSeconds(ghostWaitTime);
        ghost.gameObject.GetComponent<Animator>().Play("Ghost1_MoveDown");
        ghost.GetComponent<GhostController>().enabled = true;
        ghost.gameObject.GetComponent<NavMeshAgent>().enabled = true;
    }

    public void ResetGhost(GameObject ghost) 
    {
        ghost.GetComponent<Animator>().Play("Ghost_DeathState");
        ghost.transform.position = homePosition.position;
        ghost.GetComponent<GhostController>().enabled = false;
        ghost.GetComponent<NavMeshAgent>().enabled = false;
    }
}
