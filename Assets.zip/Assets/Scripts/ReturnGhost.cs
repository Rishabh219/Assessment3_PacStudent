using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SocialPlatforms.Impl;

public class ReturnGhost : MonoBehaviour
{
    float waitTime = 5f;
    public Transform homePosition;
    public AudioSource shootGhost;
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Ghost 1") || collision.CompareTag("Ghost 2") || collision.CompareTag("Ghost 3") || collision.CompareTag("Ghost 4")) 
        {
            shootGhost.Play();
            PacStudentController.score += 300;
            collision.gameObject.GetComponent<Animator>().Play("Ghost_DeathState");
            collision.gameObject.transform.position = homePosition.position;
            collision.GetComponent<GhostController>().enabled = false;
            collision.gameObject.GetComponent<NavMeshAgent>().enabled = false;
            StartCoroutine(GhostRecover(collision.gameObject));
            gameObject.SetActive(false);
        }
    }

    IEnumerator GhostRecover(GameObject ghost)
    {
        yield return new WaitForSeconds(waitTime);
        ghost.gameObject.GetComponent<Animator>().Play("Ghost1_MoveDown");
        ghost.GetComponent<GhostController>().enabled = true;
        ghost.gameObject.GetComponent<NavMeshAgent>().enabled = true;
    }
}
