using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using static UnityEngine.GraphicsBuffer;

public class GhostController : MonoBehaviour
{
    public Transform player;
    NavMeshAgent agent;

    public Transform ghost3Target;
    public Vector2[] ghost3Positions;
    public static int ghost3Index = 1;

    public Transform ghost4Target;
    public Vector2[] ghost4Positions;
    public static int index = 1;

    public float distanceThreshold = 1f;

    public static bool resetGhost = false;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;
    }

    void Update()
    {
        if (GameStarter.gameStarted) 
        {
            if (PacStudentController.powerPelletEaten)
            {
                if (resetGhost) 
                {
                    gameObject.GetComponent<Animator>().Play("Ghost_RecoverState");
                }
                else 
                {
                    gameObject.GetComponent<Animator>().Play("Ghost_ScaredState");
                }
                
            }

            if (!PacStudentController.powerPelletEaten && !resetGhost) 
            {
                gameObject.GetComponent<Animator>().Play("Ghost1_MoveDown");
            }

            if (gameObject.tag == "Ghost 1")
            {
                GhostOneController();
            }

            if (gameObject.tag == "Ghost 2")
            {
                GhostTwoController();
            }

            if (gameObject.tag == "Ghost 3")
            {
                GhostThreeController();
            }

            if (gameObject.tag == "Ghost 4")
            {
                GhostFourController();
            }
        }
    }

    void GhostOneController() 
    {
        agent.SetDestination(player.position); 
    }

    void GhostTwoController() 
    {
        agent.SetDestination(player.position);
    }

    void GhostThreeController()
    {
        agent.SetDestination(ghost3Target.position);

        if (Vector2.Distance(transform.position, ghost3Target.position) < distanceThreshold)
        {
            UpdateGhostThreeTarget();
        }
    }

    void GhostFourController()
    {
        agent.SetDestination(ghost4Target.position);

        if (Vector2.Distance(transform.position, ghost4Target.position) < distanceThreshold)
        {
            UpdateGhostFourTarget();
        }
    }

    void UpdateGhostFourTarget() 
    {
        ghost4Target.position = ghost4Positions[index];
        index++;

        if (index == ghost4Positions.Length - 1)
        {
            index = 0;
        }
    }

    void UpdateGhostThreeTarget()
    {
        ghost3Target.position = ghost3Positions[ghost3Index];
        ghost3Index++;

        if (ghost3Index == ghost3Positions.Length - 1)
        {
            ghost3Index = 0;
        }
    }

}
