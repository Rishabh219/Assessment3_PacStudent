using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using TMPro;
using UnityEngine.PlayerLoop;

public class GhostTimer : MonoBehaviour
{
    public TextMeshProUGUI timerText;
    public TextMeshProUGUI timerLabel;
    private float countdownTime = 10f;

    void Start()
    {
        timerText.gameObject.SetActive(false);
        timerLabel.gameObject.SetActive(false);
    }

    void Update()
    {
        if (PacStudentController.powerPelletEaten) 
        {
            timerText.gameObject.SetActive(true);
            timerLabel.gameObject.SetActive(true);
            StartCoroutine(StartCountdown());
        }
    }

    IEnumerator StartCountdown()
    {
        float currentTimer = countdownTime;

        while (currentTimer > 0)
        {
            timerText.text = currentTimer.ToString("F0");
            currentTimer -= Time.deltaTime;
            if (currentTimer <= 3 && currentTimer > 0) 
            {
                GhostController.resetGhost = true;
            }
            yield return null;
        }

        GhostController.resetGhost = false;
        timerText.gameObject.SetActive(false);
        timerLabel.gameObject.SetActive(false);
        PacStudentController.powerPelletEaten = false;
        PacStudentController.canEatPowerPellet = true;
        PacStudentController.canEatGhost = false;

    }
}