using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Level2Starter : MonoBehaviour
{
    public TextMeshProUGUI pressSpace;

    void Start()
    {
        pressSpace.gameObject.SetActive(true);
        StartCoroutine(RemoveInstructions());
    }

    IEnumerator RemoveInstructions() 
    {
        yield return new WaitForSeconds(3);
        pressSpace.gameObject.SetActive(false);
    }
}